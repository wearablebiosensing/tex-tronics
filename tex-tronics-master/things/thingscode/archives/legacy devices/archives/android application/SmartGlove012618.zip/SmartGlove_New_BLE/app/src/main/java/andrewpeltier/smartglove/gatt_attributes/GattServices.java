package andrewpeltier.smartglove.gatt_attributes;

import java.util.UUID;

/**
 * Created by mcons on 3/11/2017.
 */

public class GattServices {
    // Old Smart Glove Service
    public static final UUID SMART_GLOVE_FINGERS_SERVICE = UUID.fromString("98d4d182-4ffe-4562-90f0-c1aff5500ed3");

    // Smart Glove Nano Service
    public static final UUID IMU_SERVICE = UUID.fromString("00004000-0000-1000-8000-00805f9b34fb");
    public static final UUID DATA_READY_SERVICE = UUID.fromString("0000400a-0000-1000-8000-00805f9b34fb");
    public static final UUID FLEX_SERVICE = UUID.fromString("00004004-0000-1000-8000-00805f9b34fb");
}
