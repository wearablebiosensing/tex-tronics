package andrewpeltier.smartglove.activities.patient.exercise_activities;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.TextView;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
import java.util.ArrayList;
import andrewpeltier.smartglove.R;
import andrewpeltier.smartglove.activities.patient.ExerciseSelection;
import andrewpeltier.smartglove.storage.GatherCSVData;
import andrewpeltier.smartglove.activities.SmartGloveInterface;
import andrewpeltier.smartglove.graphs.MonitorGraph;
import andrewpeltier.smartglove.graphs.ProcessData;

/**
 * Created by Andrew on 7/7/17.
 *
 * GloveExerciseActivity refers to the three exercises that require the Smart Glove
 * to function, being the Finger Tap, Closed Grip, and Hand Flip exercises.
 */

public class GloveExerciseActivity extends AppCompatActivity implements SmartGloveInterface
{
    private static final String TAG = "GloveExerciseActivity";
    private static final String COUNTER_TEXT = "Repetitions: ";
    private static int selectedExercise;

    private static final int REQUIRED_REPS = 10;
    private static final float VISIBLE_VALUES = 20f;

    private ProcessData processData;
    private Handler handler;
    private TextView counter;
    private int count;
    private boolean halfway;

    private LineChart graphLayout;
    private LineChart dataGraph;
    private MonitorGraph monitorGraph;
    private int graphCounter = 0;
    private ArrayList<Entry> indexEntries = new ArrayList<>();
    private ArrayList<Entry> thumbEntries = new ArrayList<>();
    private ArrayList<Entry> xEntries = new ArrayList<>();
    private ArrayList<Entry> yEntries = new ArrayList<>();
    private ArrayList<Entry> zEntries = new ArrayList<>();
    private ArrayList<String> xAxis = new ArrayList<>();
    private long startTime;

    @SuppressLint("HandlerLeak")
    @Override
    protected void onCreate(Bundle savedInstanceBundle)
    {
        // Sets up screen
        super.onCreate(savedInstanceBundle);
        getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        setContentView(R.layout.glove_exercise_layout);

        // Sets up the repetition counter on the GUI
        counter = (TextView) findViewById(R.id.fingerTap_counter);
        count = 0;
        counter.setText(COUNTER_TEXT + count);

        // Gets the current time for graph timer
        startTime = System.currentTimeMillis();

        // Initializes the data processing, which allows the GATT notification to start
        // displaying the GATT values on the graph
        handler = new Handler()
        {
            public void handleMessage(Message message)
            {
                switch (message.what)
                {
                    case Graph.READY:
                        // Receives values from the ProcessData class
                        float indexFloat = processData.returnIndex();
                        float thumbFloat = processData.returnThumb();
                        // Updates the graph with those values
                        updateGraph(indexFloat, thumbFloat);
                        break;
                    case Graph.READY2:
                        float xVal = processData.returnXVal();
                        float yVal = processData.returnYVal();
                        float zVal = processData.returnZVal();
                        updateGraph(xVal, yVal, zVal);
                        break;
                    default:
                        Log.v(TAG, "Message handle error");
                }
            }
        };
        processData = new ProcessData(handler);

        //Sets up the graph
        graphLayout = (LineChart) findViewById(R.id.chart);
        dataGraph = new LineChart(this);
        monitorGraph = new MonitorGraph();

        dataGraph = monitorGraph.createChart(dataGraph);
        graphLayout.addView(dataGraph);
    }

    /** setExerciseSelection(int selection)
     *
     * Called by the ExerciseSelection activity.
     * Identifies to this activity which of the three glove exercises the user has chosen.
     * The conditions that indicate a repetition and the construction of the graph depend on
     * which activity has been chosen in order to ensure that the user is completing the
     * exercise correctly.
     *
     * @param selection
     * 1 = Finger Tap
     * 2 = Closed Grip
     * 3 = Hand Flip
     */
    public static void setExerciseSelection(int selection)
    {
        selectedExercise = selection;
    }

    /** updateGraph()
     *
     * Called from the class' handler, which is shared with the ProcessData class.
     * Updates the graph to show the latest values gathered from the glove.
     *
     * Values that are received from the glove.
     * @param indexFloat
     * @param thumbFloat
     */
    public void updateGraph(float indexFloat, float thumbFloat)
    {
        // Move to a new set of values
        graphCounter++;

        // Each entry list accumulates every new value
        indexEntries.add(new Entry(indexFloat, graphCounter));
        thumbEntries.add(new Entry(thumbFloat, graphCounter));

        // Gets the current time (in seconds) and adds it to the graph's x-axis
        xAxis.add("" + ((System.currentTimeMillis() - startTime) / 1000));

        // Creates line graph data with the updated entry lists
        LineDataSet indexDataSet = new LineDataSet(indexEntries, "Index");
        LineDataSet thumbDataSet = new LineDataSet(thumbEntries, "Thumb");
        indexDataSet.setColor(Color.BLUE);
        thumbDataSet.setColor(Color.GREEN);

        // Refreshes the graph
        dataGraph.invalidate();

        // Adds all of the line data to a single data set
        ArrayList<ILineDataSet> dataSets = new ArrayList<>();
        dataSets.add(indexDataSet);
        dataSets.add(thumbDataSet);

        // Updates the data that the graph uses
        LineData lineData = new LineData(xAxis, dataSets);
        dataGraph.setData(lineData);
        dataGraph.notifyDataSetChanged();

        // Arranges the graph to only show the latest values
        dataGraph.setVisibleXRangeMaximum(VISIBLE_VALUES);
        dataGraph.moveViewToX(graphCounter);

        // Checks to see if the user has completed one repetition
        //checkRep(indexFloat, thumbFloat);
    }

    public void updateGraph(float xFloat, float yFloat, float zFloat) {
        // Move to a new set of values
        graphCounter++;

        // Each entry list accumulates every new value
        xEntries.add(new Entry(xFloat, graphCounter));
        yEntries.add(new Entry(yFloat, graphCounter));
//        zEntries.add(new Entry(zFloat, graphCounter));

        // Gets the current time (in seconds) and adds it to the graph's x-axis
        xAxis.add("" + ((System.currentTimeMillis() - startTime) / 1000));

        // Creates line graph data with the updated entry lists
        LineDataSet xDataSet = new LineDataSet(xEntries, "X-Vals");
        LineDataSet yDataSet = new LineDataSet(yEntries, "Y-Vals");
//        LineDataSet zDataSet = new LineDataSet(zEntries, "Z-Vals");
        xDataSet.setColor(Color.RED); // Make it pop
        yDataSet.setColor(Color.GREEN);
//        zDataSet.setColor(Color.RED);

        // Refreshes the graph
        dataGraph.invalidate();

        // Adds all of the line data to a single data set
        ArrayList<ILineDataSet> dataSets = new ArrayList<>();
        dataSets.add(xDataSet);
        dataSets.add(yDataSet);
//        dataSets.add(zDataSet);

        // Updates the data that the graph uses
        LineData lineData = new LineData(xAxis, dataSets);
        dataGraph.setData(lineData);
        dataGraph.notifyDataSetChanged();

        // Arranges the graph to only show the latest values
        dataGraph.setVisibleXRangeMaximum(VISIBLE_VALUES);
        dataGraph.moveViewToX(graphCounter);
    }

    /** checkRep()
     *
     * Called by the updateGraph() method.
     * Checks to see if the user has completed a repetition based on the exercise
     * that they are currently doing.
     *
     * Values that are received from the glove.
     * @param indexFloat
     * @param thumbFloat
     */
    private void checkRep(float indexFloat, float thumbFloat)
    {
        switch(selectedExercise)
        {
            // Finger Tap
            case 1:
                // If the user has completed the exercise, return to the selection screen
                if(count == REQUIRED_REPS)
                {
                    // Stop graphing the glove's values
                    processData.setHandler(null);

                    // Save the entry lists so that they can be converted into CSV files
                    GatherCSVData.writeFingerTap(indexEntries, thumbEntries, xAxis);

                    // Tell the exercise selection screen that this exercise is completed
                    ExerciseSelection.exerciseComplete(selectedExercise);

                    // Return to the exercise selection screen
                    Intent intent = new Intent(this, ExerciseSelection.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                    finish();
                }
                // User is at the halfway point of the repetition
                else if((halfway == false) && (indexFloat > thumbFloat) && (indexFloat > 25000))
                {
                    halfway = true;
                }
                // User has completed a repetition
                else if ((halfway == true) && (thumbFloat < 20000) && (indexFloat < thumbFloat))
                {
                    count++;
                    counter.setText(COUNTER_TEXT + count);
                    halfway = false;
                }
                break;
            // Closed Grip
            case 2:
                if(count == REQUIRED_REPS)
                {
                    processData.setHandler(null);
                    try{Thread.sleep(250);}
                    catch(Exception e){Log.d(TAG, "Could not sleep due to exception " + e);}

                    GatherCSVData.writeClosedGrip(indexEntries, thumbEntries, xAxis);
                    ExerciseSelection.exerciseComplete(selectedExercise);

                    Intent intent = new Intent(this, ExerciseSelection.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                    finish();
                }
                break;
            case 3:
                break;
            default:
                Log.w(TAG, "The selected exercise was not set.");
        }
    }

    @Override
    public void onBackPressed()
    {
        processData.setHandler(null);
        Intent intent = this.getParentActivityIntent();
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
        super.onBackPressed();
    }

    @Override
    protected void onStart()
    {
        super.onStart();
    }

    @Override
    protected void onStop()
    {
        processData.setHandler(null);
        super.onStop();
    }
}