package andrewpeltier.smartglove.activities.doctor;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import andrewpeltier.smartglove.R;

/**
 * Created by Andrew on 9/19/17.
 */

public class DoctorMain extends AppCompatActivity
{
    private static final String TAG = "DoctorMain";
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_doctor);
        Log.e(TAG, "Creating MainActivity...");
    }
}
