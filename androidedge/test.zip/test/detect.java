public class detect {
	
	private detect() { }

	public static double[] linspace(double min, double max, int points) {  
    	double[] d = new double[points];  
    	for (int i = 0; i < points; i++){  
    	    d[i] = min + i * (max - min) / (points - 1);  
    	}  
    	return d;  
	}

	/**
     * Reads a 1D array of doubles from standard input and returns it.
     *
     * @return the 1D array of doubles
     */
    public static double[] readDouble1D() {
        int n = StdIn.readInt();
        double[] a = new double[n];
        for (int i = 0; i < n; i++) {
            a[i] = StdIn.readDouble();
        }
        return a;
    }
    
    /**
     * Returns the sum of all values in the specified array.
     *
     * @param  a the array
     * @return the sum of all values in the array {@code a[]};
     *         {@code 0.0} if no such value
     */
    private static double sum(double[] a) {
        double sum = 0.0;
        for (int i = 0; i < a.length; i++) {
            sum += a[i];
        }
        return sum;
    }
    
    /**
     * Returns the maximum value in the specified array.
     *
     * @param  a the array
     * @return the maximum value in the array {@code a[]};
     *         {@code Double.NEGATIVE_INFINITY} if no such value
     */
    public static double max(double[] a) {

        double max = Double.NEGATIVE_INFINITY;
        for (int i = 0; i < a.length; i++) {
            if (Double.isNaN(a[i])) return Double.NaN;
            if (a[i] > max) max = a[i];
        }
        return max;
    }

    /**
     * Returns the minimum value in the specified array.
     *
     * @param  a the array
     * @return the minimum value in the array {@code a[]};
     *         {@code Double.POSITIVE_INFINITY} if no such value
     */
    public static double min(double[] a) {

        double min = Double.POSITIVE_INFINITY;
        for (int i = 0; i < a.length; i++) {
            if (Double.isNaN(a[i])) return Double.NaN;
            if (a[i] < min) min = a[i];
        }
        return min;
    }

    /**
     * Returns the average value in the specified array.
     *
     * @param  a the array
     * @return the average value in the array {@code a[]};
     *         {@code Double.NaN} if no such value
     */
    public static double mean(double[] a) {

        if (a.length == 0) return Double.NaN;
        double sum = sum(a);
        return sum / a.length;
    }

    /**
     * Returns the sample variance in the specified array.
     *
     * @param  a the array
     * @return the sample variance in the array {@code a[]};
     *         {@code Double.NaN} if no such value
     */
    public static double var(double[] a) {

        if (a.length == 0) return Double.NaN;
        double avg = mean(a);
        double sum = 0.0;
        for (int i = 0; i < a.length; i++) {
            sum += (a[i] - avg) * (a[i] - avg);
        }
        return sum / (a.length - 1);
    }


	public static double[] convolve(double[] data, double[] kernel){       
        double[] output = new double[data.length];

        // loop through image
        for(int i = 0; i < data.length; i++)
        {      
            double outputValue = 0;

            // loop through kernel
            for(int j = 0; j < kernel.length; j++)
            {
                int neighbour = i + j - (kernel.length / 2);

                // discard out of bound neighbours 
                if (neighbour >= 0 && neighbour < data.length)
                {
                    double dataValue = data[neighbour];
                    double kernelValue = kernel[j];          
                    outputValue += dataValue * kernelValue;
                }
            }
            output[i] = outputValue;
        }        

        return output;
    }
    
    public static void main(String[] args) {
        double[] a = readDouble1D();
        //assume only 128 samples to work with
		double[] x;
		double[] absx;
		double[] xx;
		double varx;
		boolean active = false;
		// allocates memory for 128 doubles
		x = new double[128];
		absx = new double[128];
		xx = new double[128];
		varx = 0.0;
		
		x = a;
		
		xx = linspace(-64,64,128);
		

        //take the absolute value of the the signal squared
        for (int i = 0; i < x.length; i++) {
        	absx[i] = Math.pow(x[i], 2);
    	}
        
        double convx[] = convolve(absx, xx);
        varx = var(absx);
        
        if(max(convx)>100){
        	System.out.println("Action!");
    		return;
		}else if(varx>0.1753){
    		System.out.println("Action!");
    		return;
		}else if(mean(absx)*varx>0.006){
    		System.out.println("Action!");
    		return;
		}else{
    		System.out.println("Silence!");
    		return;
        }

    }
}
