package andrewpeltier.smartglove.storage;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.github.mikephil.charting.data.Entry;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import andrewpeltier.smartglove.activities.SmartGloveInterface;

/**
 * Created by Andrew on 7/26/17.
 *
 * GatherCSVData
 * Stores the values collected from the GloveExerciseActivity to be added to their respective
 * CSV files once all exercises have been completed.
 */

public class GatherCSVData
{
    private static final String TAG = "GatherCSVData";
    private static final String HEADER = "Patient, Date, Time, Timer, Index, Thumb, Middle, Ring, Pinky";

    private static ArrayList<Entry> fingerTapIndex = new ArrayList<>();
    private static ArrayList<Entry> fingerTapThumb = new ArrayList<>();
    private static ArrayList<String> fingerTapTime = new ArrayList<>();

    private static ArrayList<Entry> closedGripIndex = new ArrayList<>();
    private static ArrayList<Entry> closedGripThumb = new ArrayList<>();
    private static ArrayList<String> closedGripTime = new ArrayList<>();

    private static long screenTapTime;
    private static Context deviceContext;

    /** getHeaderInfo()
     *
     * Gets the header info used to create the header of each CSV file.
     *
     * @param mContext
     * @return
     */
    private String getHeaderInfo(Context mContext)
    {
        // Gets the name
        final SharedPreferences sharedPreferences = mContext.getSharedPreferences("myPref", 0);
        String name = sharedPreferences.getString(SmartGloveInterface.Preferences.NAME, "");

        // Gets the date and time
        Date date = Calendar.getInstance().getTime();
        String dateString = new SimpleDateFormat("MM/dd/yyyy", Locale.US).format(date);
        String timeString = new SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(date);

        // Creates and returns the header
        String header = name + "," + dateString + "," + timeString + ",";
        return header;
    }

    /**                         *** Write Methods ***
     *
     *  The following methods store the values from each exercise in this class
     */

    public static void writeFingerTap(ArrayList<Entry> indexValues, ArrayList<Entry> thumbValues, ArrayList<String> time)
    {
        fingerTapIndex = indexValues;
        fingerTapThumb = thumbValues;
        fingerTapTime = time;
    }

    public static void writeClosedGrip(ArrayList<Entry> indexValues, ArrayList<Entry> thumbValues, ArrayList<String> time)
    {
        closedGripIndex = indexValues;
        closedGripThumb = thumbValues;
        closedGripTime = time;
    }

    public static void writeScreenTap(long time)
    {
        screenTapTime = time;
    }

    /**                         *** Log Methods ***
     *
     *  The following methods logs the values from each exercise to a CSV file
     */

    public void logFingerTap(Context mContext)
    {
        int counter = 0;

        if(fingerTapIndex != null)
        {
            while(counter < fingerTapIndex.size())
            {
                String data = getHeaderInfo(mContext);
                data += fingerTapTime.get(counter) + "," + fingerTapIndex.get(counter).getVal() + "," + fingerTapThumb.get(counter).getVal();
                DataLogService.log(mContext, new File(Directories.getRootFile(mContext), "/finger_tap.csv"), data, HEADER);
                counter++;
            }
        }
    }

    public void logClosedGrip(Context mContext)
    {
        String data = getHeaderInfo(mContext);
        int counter = 0;

        while(counter < closedGripIndex.size())
        {
            data += closedGripTime.get(counter) + "," + closedGripIndex.get(counter).getVal() + "," + closedGripThumb.get(counter).getVal();
            DataLogService.log(mContext, new File(Directories.getRootFile(mContext), "/closed_grip.csv"), data, HEADER);
            counter++;
        }
    }

    public void logScreenTap(Context mContext)
    {
        String screenTapHeader = "Patient, Date, Time, Exercise Length (Seconds)";

        if(screenTapTime != 0)
        {
            String data = getHeaderInfo(mContext);
            data += screenTapTime;
            DataLogService.log(mContext, new File(Directories.getRootFile(mContext), "/screen_tap.csv"), data, screenTapHeader);
        }
    }

    public void logJunkData(int[] values, String fileName)
    {
        String data = getHeaderInfo(deviceContext);
//        data += values.get(0) + "," + values.get(1) + "," + values.get(2)+ "," + values.get(3)+ "," + values.get(4)
//                + "," + values.get(5)+ "," + values.get(6)+ "," + values.get(7)+ "," + values.get(8);

        data += values[0] + "," + values[1] + "," + values[2];
        DataLogService.log(deviceContext, new File(Directories.getRootFile(deviceContext), "/" + fileName + ".csv"), data, fileName);
        Log.v(TAG, "Data log success!");
    }

    public static void setDeviceContext(Context context)
    {
        deviceContext = context;
    }
}
