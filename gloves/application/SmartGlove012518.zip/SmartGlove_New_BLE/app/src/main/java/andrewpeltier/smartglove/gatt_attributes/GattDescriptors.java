package andrewpeltier.smartglove.gatt_attributes;

import java.util.UUID;

/**
 * Created by mcons on 3/11/2017.
 */

public class GattDescriptors {
    public static final UUID NOTIFICATION_DESCRIPTOR = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
}
