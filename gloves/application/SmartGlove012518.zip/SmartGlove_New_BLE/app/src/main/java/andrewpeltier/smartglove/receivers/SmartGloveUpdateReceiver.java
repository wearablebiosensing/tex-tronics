package andrewpeltier.smartglove.receivers;

import android.content.BroadcastReceiver;
import android.content.IntentFilter;

/**
 * Created by mcons on 3/11/2017.
 */

abstract public class SmartGloveUpdateReceiver extends BroadcastReceiver {
    public static final IntentFilter SMART_GLOVE_INTENT_FILTER = new IntentFilter("uri.egr.vapegate.update");
    public static final String EXTRA_CONNECTION_UPDATE = "uri.egr.vapegate.connection_update";
    public static final String EXTRA_READ_UPDATE = "uri.egr.vapegate.read_update";
    public static final String EXTRA_STORE_UPDATE = "uri.egr.vapegate.store_update";
    public static final String EXTRA_NOTIFY_UPDATE = "uri.egr.vapegate.notify_update";
}
