package andrewpeltier.smartglove.graphs;

import android.content.Context;
import android.os.Handler;

import java.util.ArrayList;

import andrewpeltier.smartglove.activities.SmartGloveInterface;
import andrewpeltier.smartglove.storage.GatherCSVData;

/**
 * Created by Andrew on 6/22/17.
 *
 * ProcessData
 * Gathers the data from the glove and sends it to the exercise activity to be graphed.
 */

public class ProcessData implements SmartGloveInterface
{
    private static float    indexValue;
    private static float    thumbValue;
    private static float    xVal,
                            yVal,
                            zVal;
    private static Handler handler;
    private static Context mContext;

    public static ArrayList<Integer> pressureData = new ArrayList<>();
    public static ArrayList<Float> posData = new ArrayList<>();

    public ProcessData(Handler handler){this.handler = handler;}

    public void setHandler(Handler handler) {this.handler = handler;}

    public float returnIndex()
    {
        return indexValue;
    }
    public float returnThumb()
    {
        return thumbValue;
    }
    public float returnXVal() { return xVal; }
    public float returnYVal() { return yVal; }
    public float returnZVal() { return zVal; }

    // Sends each value to be graphed
    public static void process(int value)
    {
        pressureData.add(value);
        if(pressureData.size() == 2)
        {
            indexValue = (float) pressureData.indexOf(0);
            thumbValue = (float) pressureData.indexOf(1);
            pressureData.clear();
            if(handler != null)
                handler.sendEmptyMessageDelayed(Graph.READY, 100);
        }
    }

    public static void process(int[] data)
    {
        //TODO
        // Make another list that stores sensor data and graph it from here
        xVal = Float.valueOf(Integer.toString(data[0])); //xVal = (float) data[0];
        yVal = Float.valueOf(Integer.toString(data[1])); //yVal = (float) data[1];
        zVal = (float) 0;
        if(handler != null)
            handler.sendEmptyMessageDelayed(Graph.READY2, 100);
    }

    public static void setContext(Context context)
    {
        mContext = context;
    }
}
