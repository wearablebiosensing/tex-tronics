package andrewpeltier.smartglove.gatt_attributes;

/**
 * Created by mcons on 3/11/2017.
 */

public class GattDevices {
    //SE Nano Devices
//    public static final String SMART_GLOVE_DEVICE = "CC:65:97:7D:A4:22";
//    public static final String SMART_GLOVE_DEVICE = "F6:D7:BF:73:72:D3";
    public static final String SMART_GLOVE_DEVICE = "D9:8C:12:12:BE:74";
    //Personal Nano Device
//    public static final String SMART_GLOVE_DEVICE = "E6:BE:40:61:76:DC";
    //Personal 101 Device
    public static final String SMART_GLOVE_OLD_DEVICE = "98:4F:EE:0F:A3:AB";
}
