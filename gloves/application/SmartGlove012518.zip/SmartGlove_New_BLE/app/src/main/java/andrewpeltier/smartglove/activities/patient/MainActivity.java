package andrewpeltier.smartglove.activities.patient;


import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import andrewpeltier.smartglove.R;
import andrewpeltier.smartglove.activities.SmartGloveInterface;
import andrewpeltier.smartglove.graphs.ProcessData;
import andrewpeltier.smartglove.services.SmartGloveManagerService;
import andrewpeltier.smartglove.storage.GatherCSVData;

/**
 *      Created by Andrew Peltier, June 2017
 *
 *  MainActivity
 *
 * The first screen of the application
 *
 * In this screen, the user must set a name and connect a Smart Glove device to
 * the android device using bluetooth in order to proceed to the exercises.
 */

public class MainActivity extends AppCompatActivity implements SmartGloveInterface
{
    private static final String TAG = "MainActivity";
    private Button beginButton;
    private ImageView logo;
    private static Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.e(TAG, "Creating MainActivity...");
        MainActivity.context = getApplicationContext();

        ProcessData.setContext(context);
        GatherCSVData.setDeviceContext(context);

        SmartGloveManagerService.connect(context);

        beginButton = (Button) findViewById(R.id.start_button);
        beginButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                // Code that checks to see if the glove is working correctly
                //  and if the user has inputted a name for themselves.

                //Gets the user inputted name
                SharedPreferences sharedPreferences = getSharedPreferences("myPref", 0);
                String name = sharedPreferences.getString(Preferences.NAME, "");

                //If glove is working correctly and if name is selected then launch exercise selection
                if(SmartGloveManagerService.READY && name != "")
                {
                    Log.v(TAG, "Launching ExerciseSelection Activity...");
                    Intent intent = new Intent(context, ExerciseSelection.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                    finish();
                }
                // If glove is not connected
                else if(!SmartGloveManagerService.READY)
                {
                    Toast.makeText(MainActivity.this, "Please connect your Smart Glove device.", Toast.LENGTH_SHORT).show();
                }
                // If name is not inputted
                else
                {
                    Toast.makeText(MainActivity.this, "Please set patient name.", Toast.LENGTH_SHORT).show();
                }
            }
        });
        logo = (ImageView) findViewById(R.id.logo);
        Animation fadeInAnimation = AnimationUtils.loadAnimation(this, R.anim.logofadein);
        logo.startAnimation(fadeInAnimation);
    }

    /** confirmPatient()
     *
     * Sets up a dialog box that saves the user's inputted name to the app cache.
     *
     * If a name is already saved, the dialog box will ask the user if they want to continue
     * as the user that is currently selected.
     *
     * If no name is saved, or if the user wishes to change the name, a dialog box will ask
     * the user to type in a name and save that name to the app cache.
     */
    private void confirmPatient()
    {
        //  Gets the name
        final SharedPreferences sharedPreferences = getSharedPreferences("myPref", 0);
        String name = sharedPreferences.getString(Preferences.NAME, "");

        //  Name is blank
        if(name == "")
        {
            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
            builder.setTitle("Patient Name");
            builder.setMessage("Please enter your name: ");

            final EditText input = new EditText(context);
            input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_NORMAL);
            builder.setView(input);

            builder.setPositiveButton("Save", new DialogInterface.OnClickListener()
            {
                @Override
                public void onClick(DialogInterface dialog, int which)
                {
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString(Preferences.NAME, input.getText().toString());
                    editor.commit();
                    Toast.makeText(context, "Name Saved.", Toast.LENGTH_SHORT);
                }
            });

            builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener()
            {
                @Override
                public void onClick(DialogInterface dialog, int which)
                {
                    dialog.cancel();
                }
            });
            builder.show();
        }
        // Name is entered
        else
        {
            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
            builder.setTitle("Patient Name");
            builder.setMessage("Continue as " + sharedPreferences.getString(Preferences.NAME, "") + "?");

            //User wants to change the name
            builder.setPositiveButton("Change Name", new DialogInterface.OnClickListener()
            {
                @Override
                public void onClick(DialogInterface dialog, int which)
                {
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    //Erases name, then recursively calls this method
                    editor.putString(Preferences.NAME, "");
                    editor.commit();
                    confirmPatient();
                }
            });

            builder.setNegativeButton("Yes", new DialogInterface.OnClickListener()
            {
                @Override
                public void onClick(DialogInterface dialog, int which)
                {
                    dialog.cancel();
                }
            });
            builder.show();
        }
    }

    private void confirmDisconnect()
    {
        if(!SmartGloveManagerService.READY)
        {
            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
            builder.setTitle("Disconnect");
            builder.setMessage("Smart Glove is not currently connected.");

            builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener()
            {
                @Override
                public void onClick(DialogInterface dialog, int which)
                {
                    dialog.cancel();
                }
            });
            builder.show();
        }
        else
        {
            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
            builder.setTitle("Disconnect");
            builder.setMessage("Disconnect from Smart Glove?");

            //User wants to change the name
            builder.setPositiveButton("Disconnect", new DialogInterface.OnClickListener()
            {
                @Override
                public void onClick(DialogInterface dialog, int which)
                {
                    SmartGloveManagerService.disconnect(context);
                }
            });

            builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener()
            {
                @Override
                public void onClick(DialogInterface dialog, int which)
                {
                    dialog.cancel();
                }
            });
            builder.show();
        }
    }

    @Override
    protected void onStart()
    {
        super.onStart();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    /** onCreateOptionsMenu
     *
     * Creates a menu at the top right side of the application that allows
     * the user to connect to and disconnect from a Smart Glove device.
     *
     * It also allows the user to keep, change, or set their username.
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    /** onOptionsItemSelected
     *
     * Called when the user selects an item from the options menu
     *
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch (item.getItemId())
        {
            // Connects to a device
            case R.id.reconnect:
                // Attempts to reconnect to device
                SmartGloveManagerService.connect(context);
                return true;
            // Reveals disconnect options via a dialog box
            case R.id.ble_disconnect:
                confirmDisconnect();
                return true;
            // Reveals username options via a dialog box
            case R.id.change_name:
                confirmPatient();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
