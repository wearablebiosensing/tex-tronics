package andrewpeltier.smartglove.gatt_attributes;

import java.util.UUID;

/**
 * Created by mcons on 3/11/2017.
 */

public class GattCharacteristics
{
    // Old Smart Glove Chars
    public static UUID INDEX_CHARACTERISTIC = UUID.fromString("1a417579-d50f-43ca-86d2-3bbc9eec393f");
    public static UUID THUMB_CHARACTERISTIC = UUID.fromString("381cc05a-6064-4ffb-8146-c71dc21a9b97");

    // Smart Glove Nano Chars
    public static final UUID DATA_READY_CHAR = UUID.fromString("0000400b-0000-1000-8000-00805f9b34fb");
    public static final UUID ACCEL_CHAR = UUID.fromString("00004001-0000-1000-8000-00805f9b34fb");
    public static final UUID GYRO_CHAR = UUID.fromString("00004002-0000-1000-8000-00805f9b34fb");
    public static final UUID MAGNOMETER_CHAR = UUID.fromString("00004003-0000-1000-8000-00805f9b34fb");

    // Flex Chars
    public static final UUID THUMB_CHAR = UUID.fromString("00004005-0000-1000-8000-00805f9b34fb");
    public static final UUID INDEX_CHAR = UUID.fromString("00004006-0000-1000-8000-00805f9b34fb");
}
