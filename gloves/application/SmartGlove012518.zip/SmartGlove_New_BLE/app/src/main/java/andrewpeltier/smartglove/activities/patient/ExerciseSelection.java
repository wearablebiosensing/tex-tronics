package andrewpeltier.smartglove.activities.patient;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageButton;
import android.widget.LinearLayout;

import andrewpeltier.smartglove.R;

/**
 * Created by Andrew on 5/24/17.
 */

public class ExerciseSelection extends AppCompatActivity
{
    private static final String TAG = "ExerciseSelection";

    private static boolean  fingerTapComplete = false,
                            closedGripComplete = false,
                            handFlipComplete = false,
                            screenTapComplete = false;

    private ImageButton     fingerTapButton,
                            closedGripButton,
                            handFlipButton,
                            screenTapButton;

    private static int exerciseSelection;
    private static Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        // Sets up activity
        super.onCreate(savedInstanceState);
        getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        setContentView(R.layout.exercise_selection_layout);
        context = this;
        Log.e(TAG, "Creating ExerciseSelection Activity...");

        // Checks to see which exercises are complete
        checkCompletion();

        // Sets up image buttons
        fingerTapButton = (ImageButton) findViewById(R.id.fingertap_button);
        closedGripButton = (ImageButton) findViewById(R.id.closedgrip_button);
        handFlipButton = (ImageButton) findViewById(R.id.handflip_button);
        screenTapButton = (ImageButton) findViewById(R.id.screentap_button);

        // Greys out image buttons if corresponding exercise is complete
        if(fingerTapComplete)
            fingerTapButton.setBackgroundColor(Color.GRAY);
        if(closedGripComplete)
            closedGripButton.setBackgroundColor(Color.GRAY);
        if(handFlipComplete)
            handFlipButton.setBackgroundColor(Color.GRAY);
        if(screenTapComplete)
            screenTapButton.setBackgroundColor(Color.GRAY);

        // Sets click listeners
        fingerTapButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                if(!fingerTapComplete)
                    launchInstructionActivity(1);
            }
        });

        closedGripButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                if(!closedGripComplete)
                    launchInstructionActivity(2);
            }
        });

        handFlipButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                if(!handFlipComplete)
                    launchInstructionActivity(3);
            }
        });

        screenTapButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                if(!screenTapComplete)
                    launchInstructionActivity(4);
            }
        });
    }

    private void launchInstructionActivity(int selection)
    {
        Log.v(TAG, "Launching ExerciseInstructions Activity...");
        exerciseSelection = selection;
        Intent intent = new Intent(context, ExerciseInstructions.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
        finish();
    }

    private void checkCompletion()
    {
        Log.e(TAG, "Checking Completion...");
//        if(fingerTapComplete && closedGripComplete && handFlipComplete && screenTapComplete)
//        {
//            // All activities are completed
//        Log.v(TAG, "Launching Finish Activity...");
//        Intent intent = new Intent(context, FinishActivity.class);
//        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//        startActivity(intent);
//        finish();
//        }
        if(screenTapComplete && fingerTapComplete)
        {
            Log.v(TAG, "Launching Finish Activity...");
            Intent intent = new Intent(context, FinishActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            finish();
        }
        Log.e(TAG, "Not all activities are completed.");
    }

    public void resetCompletion()
    {
        fingerTapComplete = false;
        closedGripComplete = false;
        handFlipComplete= false;
        screenTapComplete = false;
    }

    public static int getExerciseSelection(){return exerciseSelection;}

    public static void exerciseComplete(int exercise)
    {
        switch(exercise)
        {
            case 1:
                fingerTapComplete = true;
                break;
            case 2:
                closedGripComplete = true;
                break;
            case 3:
                handFlipComplete = true;
                break;
            case 4:
                screenTapComplete = true;
                break;
        }
    }

    @Override
    protected void onStart()
    {
        super.onStart();
    }

    @Override
    protected void onStop()
    {
        super.onStop();
    }

    @Override
    public void onBackPressed()
    {
        Log.e(TAG, "Back pressed. Navigating to " + getParentActivityIntent());
        Intent intent = this.getParentActivityIntent();
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
        super.onBackPressed();
    }
}
