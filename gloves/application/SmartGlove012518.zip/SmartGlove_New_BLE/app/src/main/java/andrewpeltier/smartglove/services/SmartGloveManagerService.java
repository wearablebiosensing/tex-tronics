package andrewpeltier.smartglove.services;

import android.app.Service;
import android.bluetooth.BluetoothGattCharacteristic;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.util.Log;

import java.util.UUID;

import andrewpeltier.smartglove.gatt_attributes.GattCharacteristics;
import andrewpeltier.smartglove.gatt_attributes.GattServices;
import andrewpeltier.smartglove.graphs.ProcessData;
import andrewpeltier.smartglove.graphs.UartEvaluator;
import andrewpeltier.smartglove.receivers.SmartGloveUpdateReceiver;
import andrewpeltier.smartglove.storage.GatherCSVData;


/**
 * Created by mcons on 3/11/2017.
 */

public class SmartGloveManagerService extends Service {
    public static final String TAG = "SmartGloveManager";
    public static final String ACTION_CONNECT = "uri.egr.vapegate.connect";
    public static final String ACTION_DISCONNECT = "uri.egr.vapegate.disconnect";
    public static final String ACTION_REQUEST_READ = "uri.egr.vapegate.read";

    private boolean mServiceBound;
    private BleConnectionService mService;
    private ServiceConnection mServiceConnection;
    private GatherCSVData gatherCSVData;

    private int value1;
    private int value2;
    public static boolean READY;

    private BroadcastReceiver mBLEUpdateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Log.d("BLE", "Received Update");
            String action = intent.getStringExtra(BleConnectionService.INTENT_EXTRA);
            switch (action) {
                case BleConnectionService.GATT_STATE_CONNECTED:
                    mService.discoverServices();
                    READY = true;
                    break;
                case BleConnectionService.GATT_STATE_DISCONNECTED:
                    Intent updateIntent2 = new Intent(SmartGloveUpdateReceiver.SMART_GLOVE_INTENT_FILTER.getAction(0));
                    updateIntent2.putExtra(SmartGloveUpdateReceiver.EXTRA_CONNECTION_UPDATE, false);
                    sendBroadcast(updateIntent2);
                    break;
                case BleConnectionService.GATT_DISCOVERED_SERVICES:
                    // Data ready character notification
                    BluetoothGattCharacteristic characteristic = mService.getCharacteristic(GattServices.DATA_READY_SERVICE, GattCharacteristics.DATA_READY_CHAR);
                    if (characteristic != null) {
                        mService.enableNotifications(characteristic);
                    }
                    // INDEX Characteristic Notification
//                    characteristic = mService.getCharacteristic(GattServices.FLEX_SERVICE, GattCharacteristics.INDEX_CHAR);
//                    if (characteristic != null) {
//                        mService.enableNotifications(characteristic);
//                    }
//                    // THUMB Characteristic Notification
//                    characteristic = mService.getCharacteristic(GattServices.FLEX_SERVICE, GattCharacteristics.THUMB_CHAR);
//                    if (characteristic != null) {
//                        mService.enableNotifications(characteristic);
//                    }
//                    Intent updateIntent1 = new Intent(SmartGloveUpdateReceiver.SMART_GLOVE_INTENT_FILTER.getAction(0));
//                    updateIntent1.putExtra(SmartGloveUpdateReceiver.EXTRA_CONNECTION_UPDATE, true);
//                    sendBroadcast(updateIntent1);
                    break;
                case BleConnectionService.GATT_CHARACTERISTIC_NOTIFY:
                    UUID characterUUID = UUID.fromString(intent.getStringExtra(BleConnectionService.INTENT_CHARACTERISTIC));
                    if(characterUUID.equals(GattCharacteristics.DATA_READY_CHAR))
                        requestRead(0);
                    else if(characterUUID.equals(GattCharacteristics.INDEX_CHAR))
                    {
                        //TODO
                        // Might have to read the characteristic manually
                        BluetoothGattCharacteristic indexChar = mService.getCharacteristic(
                                GattServices.FLEX_SERVICE, GattCharacteristics.INDEX_CHAR);
                        Log.d(TAG, "Inside the Index char");

                        int indexVal = indexChar.getIntValue(BluetoothGattCharacteristic.FORMAT_UINT16, 0);
                        // Prints value
                        Log.d(this.getClass().getSimpleName(), "Value Received:\n\tIndex Value:\t" + indexVal);
                        ProcessData.process(indexVal);
                    }
                    else if(characterUUID.equals(GattCharacteristics.THUMB_CHAR))
                    {
                        //TODO
                        // Might have to read the characteristic manually
                        BluetoothGattCharacteristic thumbChar = mService.getCharacteristic(
                                GattServices.FLEX_SERVICE, GattCharacteristics.THUMB_CHAR);
                        Log.d(TAG, "Inside the Thumb char");

                        int thumbVal = thumbChar.getIntValue(BluetoothGattCharacteristic.FORMAT_UINT16, 0);
                        Log.d(this.getClass().getSimpleName(), "Value Received:\n\tThumb Value:\t" + thumbVal);
                        ProcessData.process(thumbVal);
                    }
                    Intent updateIntent = new Intent(SmartGloveUpdateReceiver.SMART_GLOVE_INTENT_FILTER.getAction(0));
                    updateIntent.putExtra(SmartGloveUpdateReceiver.EXTRA_NOTIFY_UPDATE, true); // No Way. No way
                    sendBroadcast(updateIntent);
                    break;
                case BleConnectionService.GATT_CHARACTERISTIC_READ:
                    //Check characteristic
                    //If data ready char, request read
                    UUID charUUID = UUID.fromString(intent.getStringExtra(BleConnectionService.INTENT_CHARACTERISTIC));
                    byte[] data = intent.getByteArrayExtra(BleConnectionService.INTENT_DATA);

                    if(charUUID.equals(GattCharacteristics.INDEX_CHAR))
                    {
                        //Parse contents from data here
                        // You
                        int xAxis, yAxis, zAxis;
                        BluetoothGattCharacteristic gattCharacteristic = mService.getCharacteristic(
                                GattServices.FLEX_SERVICE, GattCharacteristics.INDEX_CHAR);

                        Log.d(TAG, "Inside the index char");

//                        xAxis = gattCharacteristic.getIntValue(BluetoothGattCharacteristic.FORMAT_UINT16, 4);
//                        yAxis = gattCharacteristic.getIntValue(BluetoothGattCharacteristic.FORMAT_UINT16, 2);
                        value1 = gattCharacteristic.getIntValue(BluetoothGattCharacteristic.FORMAT_UINT8, 1);

                        // Prints value
//                        Log.d(this.getClass().getSimpleName(), "Value Received:\n\tData:\t" + data +
//                                "\n\tX Axis:\t" + xAxis + "\n\tY Axis:\t" + yAxis + "\n\tZ Axis:\t" + zAxis);

                        // Log the data directly
//                        sendBroadcast(generateIntent(BleConnectionService.GATT_INFORMATION_STORE,
//                                new int[]{xAxis, yAxis, zAxis}, "accel"));

                        Log.d(TAG, "Index int value: " + value1);
                        Log.d(TAG, "Index value: " + gattCharacteristic.getValue()[0]);
                        Log.d(TAG, "Index value: " + gattCharacteristic.getValue()[1]);


                        // Graph the data
//                        ProcessData.process(zAxis);

                        // Get data from the next character
                        requestRead(1);
                    }
                    else if(charUUID.equals(GattCharacteristics.THUMB_CHAR))
                    {
                        int xAxis, yAxis, zAxis;
                        BluetoothGattCharacteristic gattCharacteristic = mService.getCharacteristic(
                                GattServices.FLEX_SERVICE, GattCharacteristics.THUMB_CHAR);

                        Log.d(TAG, "Inside the thumb char");

//                        xAxis = gattCharacteristic.getIntValue(BluetoothGattCharacteristic.FORMAT_UINT16, 4);
//                        yAxis = gattCharacteristic.getIntValue(BluetoothGattCharacteristic.FORMAT_UINT16, 2);
                        value2 = gattCharacteristic.getIntValue(BluetoothGattCharacteristic.FORMAT_UINT8, 1);

                        Log.d(TAG, "Thumb int value: " + value2);
                        Log.d(TAG, "Thumb value: " + gattCharacteristic.getValue()[0]);
                        Log.d(TAG, "Thumb value: " + gattCharacteristic.getValue()[1]);

                        // Prints value
//                        Log.d(this.getClass().getSimpleName(), "Value Received:\n\tData:\t" + data +
//                                "\n\tX Axis:\t" + xAxis + "\n\tY Axis:\t" + yAxis + "\n\tZ Axis:\t" + zAxis);

                        // Log the data directly
//                        sendBroadcast(generateIntent(BleConnectionService.GATT_INFORMATION_STORE,
//                                new int[]{xAxis, yAxis, zAxis}, "gyro"));

//                        // Graph the data
                        ProcessData.process(new int[]{value1, value2});

                        // Get data from the next character
                       // requestRead(2);
                    }
                    else if(charUUID.equals(GattCharacteristics.MAGNOMETER_CHAR))
                    {
                        int xAxis, yAxis, zAxis;
                        BluetoothGattCharacteristic gattCharacteristic = mService.getCharacteristic(
                                GattServices.IMU_SERVICE, GattCharacteristics.MAGNOMETER_CHAR);

                        Log.d(TAG, "Inside the magno char");

                        xAxis = gattCharacteristic.getIntValue(BluetoothGattCharacteristic.FORMAT_UINT16, 4);
                        yAxis = gattCharacteristic.getIntValue(BluetoothGattCharacteristic.FORMAT_UINT16, 2);
                        zAxis = gattCharacteristic.getIntValue(BluetoothGattCharacteristic.FORMAT_UINT16, 0);

                        // Prints value
//                        Log.d(this.getClass().getSimpleName(), "Value Received:\n\tData:\t" + data +
//                                "\n\tX Axis:\t" + xAxis + "\n\tY Axis:\t" + yAxis + "\n\tZ Axis:\t" + zAxis);

                        // Log the data directly
//                        sendBroadcast(generateIntent(BleConnectionService.GATT_INFORMATION_STORE,
//                                new int[]{xAxis, yAxis, zAxis}, "magno"));

//                        // Graph the data
//                        ProcessData.process(new int[]{xAxis, yAxis, zAxis});
                    }

                    updateIntent = new Intent(SmartGloveUpdateReceiver.SMART_GLOVE_INTENT_FILTER.getAction(0));
                    updateIntent.putExtra(SmartGloveUpdateReceiver.EXTRA_READ_UPDATE, data);
                    sendBroadcast(updateIntent);
                    break;
                case BleConnectionService.GATT_INFORMATION_STORE:
                    gatherCSVData = new GatherCSVData();
                    gatherCSVData.logJunkData(
                            intent.getIntArrayExtra(BleConnectionService.INTENT_DATA),
                            intent.getStringExtra(BleConnectionService.INTENT_CHARACTERISTIC)
                    );
                    updateIntent = new Intent(SmartGloveUpdateReceiver.SMART_GLOVE_INTENT_FILTER.getAction(0));
                    updateIntent.putExtra(SmartGloveUpdateReceiver.EXTRA_STORE_UPDATE, true); // No Way. No way
                    sendBroadcast(updateIntent);
                    break;
                case BleConnectionService.GATT_DESCRIPTOR_WRITE:
                    break;
                case BleConnectionService.GATT_NOTIFICATION_TOGGLED:
                    break;
                case BleConnectionService.GATT_DEVICE_INFO_READ:
                    break;
            }
        }
    };

    public static void connect(Context context) {
        Intent intent = new Intent(context, SmartGloveManagerService.class);
        intent.setAction(ACTION_CONNECT);
        context.startService(intent);
    }

    public static void disconnect(Context context) {
        Intent intent = new Intent(context, SmartGloveManagerService.class);
        intent.setAction(ACTION_DISCONNECT);
        context.startService(intent);
    }

    public static void requestRead(Context context) {
        Intent intent = new Intent(context, SmartGloveManagerService.class);
        intent.setAction(ACTION_REQUEST_READ);
        context.startService(intent);
    }

    @Override
    public void onCreate() {
        super.onCreate();

        mServiceConnection = new BleServiceConnection();

        registerReceiver(mBLEUpdateReceiver, new IntentFilter(BleConnectionService.INTENT_FILTER_STRING));
        bindService(new Intent(this, BleConnectionService.class), mServiceConnection, Context.BIND_AUTO_CREATE);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startID) {
        if (intent == null) {
            return START_REDELIVER_INTENT;
        }

        switch (intent.getAction()) {
            case ACTION_CONNECT:
                connect();
                break;
            case ACTION_DISCONNECT:
                disconnect();
                break;
            case ACTION_REQUEST_READ:
                break;
        }
        return START_REDELIVER_INTENT;
    }

    @Override
    public void onDestroy() {
        unbindService(mServiceConnection);
        unregisterReceiver(mBLEUpdateReceiver);

        super.onDestroy();
    }

    private void connect() {
        if (mServiceBound) {
            mService.connect();
        } else {
            log("Cannot Connect - BLE Connection Service is not bound yet!");
        }
    }

    private void disconnect() {
        if (mServiceBound) {
            mService.disconnect();
        } else {
            log("Could not Disconnect - BLE Connection Service is not bound!");
        }
    }

    private void requestRead(int i) {
        if (mServiceBound)
        {
            BluetoothGattCharacteristic characteristic = null;

            switch(i)
            {
                case 0:
                    characteristic = mService.getCharacteristic(GattServices.FLEX_SERVICE, GattCharacteristics.INDEX_CHAR);
                    Log.d(TAG, "Reading accel char...");
                    break;
                case 1:
                    characteristic = mService.getCharacteristic(GattServices.FLEX_SERVICE, GattCharacteristics.THUMB_CHAR);
                    Log.d(TAG, "Reading gyro char...");
                    break;
                case 2:
                    characteristic = mService.getCharacteristic(GattServices.IMU_SERVICE, GattCharacteristics.MAGNOMETER_CHAR);
                    Log.d(TAG, "Reading magnometer char...");
                    break;
                default:
                    Log.d(TAG, "Could not receive characteristic : For Loop Error");
            }
            mService.readCharacteristic(characteristic);
        }

        else {
            log("Could not read from Glove - BLE Connection Service is not bound!");
        }
    }

    private void log(String message) {
        Log.d("SmartGloveManager", message);
    }

    private Intent generateIntent(String action, int[] data, String charType)
    {
        Intent intent = new Intent(BleConnectionService.INTENT_FILTER_STRING);
        intent.putExtra(BleConnectionService.INTENT_EXTRA, action);
        intent.putExtra(BleConnectionService.INTENT_DATA, data);
        intent.putExtra(BleConnectionService.INTENT_CHARACTERISTIC, charType);
        return intent;
    }

    private class BleServiceConnection implements ServiceConnection {
        @Override
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            mServiceBound = true;
            mService = ((BleConnectionService.BLEConnectionBinder) iBinder).getService();
            mService.connect();
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {
            mServiceBound = false;
        }
    }
}
